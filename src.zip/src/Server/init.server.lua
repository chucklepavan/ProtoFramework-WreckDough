local replicatedStorage = game:GetService("ReplicatedStorage")

local Proto = require(replicatedStorage.Proto)
Proto:start()